#! /venv/bin/python
import json
import pymysql as mysql

def setup_mysql(mysql_config):
    with open(str(mysql_config)) as config:
        cfg = json.load(config)
    mysql_conn = mysql.connect(host = cfg['host'],
                               user = cfg['user'],
                               passwd = cfg['passwd'],
                               db = cfg['db'],
                               port= cfg['port'])
    return mysql_conn

def tokenize(path, type):
    if type is 'txt':
        file = open(path)
        tokens = file.read().split()
        return tokens

def write_json(data):
    with open('words.json', 'w') as outfile:
        json.dump(data, outfile)


if __name__ == '__main__':
    file = tokenize('lorem ipsum.txt','txt')
    write_json(file)
    setup_mysql('mysql.json')